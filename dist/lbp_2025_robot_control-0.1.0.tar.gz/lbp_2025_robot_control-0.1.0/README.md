# MOTION CONTROL FOR THE LBP 2025 Robot @ University of Augsburg
 